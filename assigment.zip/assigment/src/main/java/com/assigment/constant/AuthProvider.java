package com.assigment.constant;

public enum  AuthProvider {
    local,
    google,
}
